# Sign-Language-Detection > 2024-04-07 3:10pm
https://universe.roboflow.com/khushi-porgl/sign-language-detection-hks67

Provided by a Roboflow user
License: CC BY 4.0

